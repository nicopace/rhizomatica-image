<?
	require_once('modules/access_manager.php');
	
	$access = new AccessManager();
	$access->logout();
?>
