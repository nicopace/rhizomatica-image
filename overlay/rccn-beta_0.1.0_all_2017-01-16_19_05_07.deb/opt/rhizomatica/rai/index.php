<?php 

require_once('include/header.php');
require_once('include/menu.php'); 

print_menu(); 

?>
			<br/><br/>
			<div class="spacer"></div>
		</div>
	</body>

</html>
