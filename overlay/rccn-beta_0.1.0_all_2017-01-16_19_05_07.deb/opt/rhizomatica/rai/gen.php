<?php
echo password_hash(",.admin1", PASSWORD_DEFAULT)."\n";
?>
