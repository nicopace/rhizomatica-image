#!/bin/bash
msgmerge en.po messages.pot > en_new.po
