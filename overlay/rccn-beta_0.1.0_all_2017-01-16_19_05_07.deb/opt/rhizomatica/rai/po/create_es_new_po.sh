#!/bin/bash
msgmerge es.po messages.pot > es_new.po
